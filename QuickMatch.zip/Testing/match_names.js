const fs = require("fs");
const readline = require("readline");

const namesFile = "names.txt";
const combosFile = "combos.txt";
const outputFile = "matches.txt";

const names = new Set(
  fs.readFileSync(namesFile, "utf8")
    .split(/\r?\n/)
    .map(x => x.trim().toLowerCase())
    .filter(Boolean)
);

const input = fs.createReadStream(combosFile);
const output = fs.createWriteStream(outputFile);

const rl = readline.createInterface({ input });

let checked = 0;
let matched = 0;

rl.on("line", line => {
  checked++;

  const colonIndex = line.indexOf(":");
  if (colonIndex === -1) return;

  const username = line.slice(0, colonIndex).trim().toLowerCase();

  if (names.has(username)) {
    output.write(line + "\n");
    matched++;
  }

  if (checked % 1000000 === 0) {
    console.log(`Checked ${checked.toLocaleString()} lines, found ${matched.toLocaleString()} matches...`);
  }
});

rl.on("close", () => {
  output.end();
  console.log(`Done! Checked ${checked.toLocaleString()} lines.`);
  console.log(`Found ${matched.toLocaleString()} matches.`);
  console.log(`Saved to ${outputFile}`);
});